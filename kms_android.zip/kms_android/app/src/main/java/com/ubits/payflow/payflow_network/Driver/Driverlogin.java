package com.ubits.payflow.payflow_network.Driver;

import android.app.Activity;
import android.app.Fragment;
import android.app.TabActivity;
import android.os.Bundle;
import android.widget.Toolbar;

import com.ubits.payflow.payflow_network.R;

import butterknife.BindView;

public class Driverlogin extends Fragment {

    @BindView(R.id.toolbar)
    private Toolbar toolbar;

    public void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        toolbar.setTitle("Driver Login");

    }
}
