package com.ubits.payflow.payflow_network;

/**
 * Created by sauda on 2017/08/10.
 */

public class Application {
    private String title;
    private String totalDl;
    private String rating;
    private String icon;

    public String getTitle() {
        return title;
    }
    public void setTitle(String title) {
        this.title = title;
    }
    public String getTotalDl() {
        return totalDl;
    }
    public void setTotalDl(String totalDl) {
        this.totalDl = totalDl;
    }
    public String getRating() {
        return rating;
    }
    public void setRating(String rating) {
        this.rating = rating;
    }
    public String getIcon() {
        return icon;
    }
    public void setIcon(String icon) {
        this.icon = icon;
    }
}